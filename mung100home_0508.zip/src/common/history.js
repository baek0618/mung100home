import { createBrowserHistory } from "history";

const customHistory = createBrowserHistory();

export default customHistory;
